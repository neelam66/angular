app.controller("appController",function($scope)
{
	$scope.name = "Neelam";
});